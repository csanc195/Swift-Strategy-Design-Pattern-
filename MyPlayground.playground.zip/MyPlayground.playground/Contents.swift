/*
This is the STRATEGY DESIGN PATTERN interpreted by me in Swift,
this is a simple Swift playground that serves as proof of concept
notice that the book "Head First Design Patterns by Eric Freeman
and Elisabeth Robson in Java" was used as reference, the following principles
can be found in this book under "Strategy Design Pattern"
Strategy Design Pattern there 3 basic principles to follow:

1- Identify aspects of your application that vary and separate them from what stays the same.
2- Program to an interface, not an implementation.
3- Favor composition over inheritance.

*/

protocol FlyBehavior {
    func fly()
}

class FlyWithWings: FlyBehavior {
    
    func fly() {
        print("I am flying!")
    }
}

class FlyNoWay: FlyBehavior {
    func fly() {
        print("I cant fly! :(")
    }
}
class FlyWithRocket: FlyBehavior {
    func fly() {
        print("I am Flying with a rocket!")
    }
}

class Duck {
    var flyBehavior: FlyBehavior
    
    init(_ flyBehavior: FlyBehavior) {
        self.flyBehavior = flyBehavior
    }
    func describeDuck(){
    }
}

class mallardDuck: Duck {
    
    let duckName: String
    
    override init(_ flyBehavior: FlyBehavior){
        self.duckName = "Mallard Duck"
        super.init(flyBehavior)
    }
    override func describeDuck() {
        print("\(duckName)")
    }
}

class RubberDuck: Duck {
    let duckName: String
    
    override init(_ flyBehavior: FlyBehavior) {
        duckName = "Rubber Duck"
        super.init(flyBehavior)
    }
    override func describeDuck() {
        print("\(duckName)")
    }
}


class RocketDuck: Duck {
    let duckName: String
    
    override init(_ flyBehavior: FlyBehavior){
        duckName = "Rocket Duck"
        super.init(flyBehavior)
    }
    override func describeDuck() {
        print("\(duckName)")
    }
}


// This design pattern allows to define a family of algorithms aka behaviors
// encapsulating each one and makes them interchangeable. Strategy puts the principle
// of programming to an interface or supertype, not to a implementation.

// create some fly behavior and create a new Duck and assign this behavior to it:
let someFlyBehavior: FlyBehavior = FlyWithWings()
var someDuck: Duck = mallardDuck(someFlyBehavior)
someDuck.describeDuck()
someDuck.flyBehavior.fly()

// Change the behavior of the object to flyNoWay()
print("------------")
someDuck.flyBehavior = FlyNoWay()
someDuck.describeDuck(); someDuck.flyBehavior.fly()

// Create another Duck and assign it a fly behavior
print("------------")
var anotherDuck: Duck = RubberDuck(FlyNoWay())
anotherDuck.describeDuck(); anotherDuck.flyBehavior.fly()
// Change the behavior of the previous object
print("------------")
anotherDuck.flyBehavior = FlyWithRocket()
anotherDuck.describeDuck(); anotherDuck.flyBehavior.fly()





